
var pass1 = localStorage.getItem('pass1');
var pass2 = localStorage.getItem('pass2');

function login()
{
  if(pass2 ==null)
  {
    pass2 = "password";
  }
  if(pass1 == null)
  {
    pass1 = "password"
  }

  if(document.getElementById('user').value == "user1" && document.getElementById('pass').value == pass1)
  {
    sessionStorage.setItem('userDisp', document.getElementById('user').value);
    window.open("index2.html");
  }
  else if(document.getElementById('user').value == "user2" && document.getElementById('pass').value == pass2)
  {
    sessionStorage.setItem('userDisp', document.getElementById('user').value);
    window.open("index2.html");
  }
  else {
    alert("Wrong username or password");
  }
}
