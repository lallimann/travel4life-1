var sav = 500.0;
var check = 500.0;
var otherSav = 500.0;
var otherCheck = 500.0
var creditTotal  = 1000.0;
var creditAvail = 1000.0;
var selectedFrom = "null";
var selectedTo = "null";

var u1Out = [];
var u1In = [];
var u1Date = [];
var u1Bal = [];

var u2Out = [];
var u2In = [];
var u2Date = [];
var u2Bal = [];

$("#dName").text("WELCOME: " + sessionStorage.getItem('userDisp'));


$(document).ready(function(){

  if(sessionStorage.getItem('userDisp') == "user1")
  {
    var user1Sav=localStorage.getItem('u1Sav');
    var user1Chk=localStorage.getItem('u1Chk');
    var user1Credit=localStorage.getItem('u1Credit');

    if(user1Chk== null && user1Sav==null && user1Credit==null)
    {
      localStorage.setItem('u1Sav',500);
      localStorage.setItem('u1Chk',500);
      localStorage.setItem('u1Credit',1000);
    }
    else {
      sav = localStorage.getItem('u1Sav');
      check = localStorage.getItem('u1Chk');
      creditAvail = localStorage.getItem('u1Credit');
    }
  }
  if(sessionStorage.getItem('userDisp') == "user2")
  {
    var user2Sav=localStorage.getItem('u2Sav');
    var user2Chk=localStorage.getItem('u2sChk');
    var user2Credit=localStorage.getItem('u2Credit');

    if(user2Chk== null && user2Sav==null && user2Credit==null)
    {
      localStorage.setItem('u2Sav',500);
      localStorage.setItem('u2Chk',500);
      localStorage.setItem('u2Credit',1000);
    }
    else {
      sav = localStorage.getItem('u2Sav');
      check = localStorage.getItem('u2Chk');
      creditAvail = localStorage.getItem('u2Credit');
    }
  }
  $("#currentB").text("saving = " + sav + "$ checking =" + check + "$");
  $("#credit").text("Total = " + creditTotal + "$ Available =" + creditAvail + "$");

  $("#savingF").click(function(){
    savingF();
  });

  $("#checkingF").click(function(){
    checkingF();
  });

  $("#savingT").click(function(){
    savingT();
  });

  $("#checkingT").click(function(){
    checkingT();
  });

  $("#othersT").click(function(){
    othersT();
  });

  $("#trans").click(function(){
    trans();
  });

  $("#chPass").click(function(){
    cPass();
  });

  $("#vCheck").click(function(){
    voidC();
  });

  $("#exit").click(function(){
    exit();
  });

  $("#aSumm").click(function(){
    sum();
  });

});

function sum()
{
  window.open("sum.html");
}

function exit()
{
  window.close();
}

function voidC()
{
  sessionStorage.setItem('userN',sessionStorage.getItem('userDisp'));

  window.open("index4.html");
}

function cPass()
{
  if(sessionStorage.getItem('userDisp') == "user1")
  {
    var newPass = $("#passInput").val();
    localStorage.setItem('pass1',newPass);
    alert("Password changed successfully")
  }

  if(sessionStorage.getItem('userDisp') == "user2")
  {
    var newPass = $("#passInput").val();
    localStorage.setItem('pass2',newPass);
    alert("Password changed successfully")
  }
}

function savingF()
{
  var checkBox = $("#savingF")[0];
  var checkBoxC = $("#checkingF")[0];
    if (checkBox.checked == true){
      checkBoxC.checked = false;
        selectedFrom = "saving"
    }
}

function checkingF()
{
  var checkBoxS = $("#savingF")[0];
  var checkBox = $("#checkingF")[0];
    if (checkBox.checked == true){
      checkBoxS.checked = false;
        selectedFrom = "checking"
    }
}

function savingT()
{
  var checkBoxC = $("#checkingT")[0];
  var checkBoxO = $("#othersT")[0];
  var checkBox = $("#savingT")[0];
    if (checkBox.checked == true){
        selectedTo = "saving"
        checkBoxO.checked = false;
        checkBoxC.checked = false;
    }
}

function checkingT()
{
  var checkBoxO = $("#othersT")[0];
  var checkBoxS = $("#savingT")[0];
  var checkBox = $("#checkingT")[0];
    if (checkBox.checked == true){
        selectedTo = "checking"
        checkBoxO.checked = false;
        checkBoxS.checked = false;
    }
}

function othersT()
{
  var checkBoxC = $("#checkingT")[0];
  var checkBoxS = $("#savingT")[0];
  var checkBox = $("#othersT")[0];
    var text = $("#othersU")[0];
    if (checkBox.checked == true){
      checkBoxC.checked = false;
      checkBoxS.checked = false;
        text.disabled = false;
        selectedTo = "others"
    } else {
       text.disabled = true;
    }
}

function trans()
{
  var amount = $("#amount").val();

if(isNaN(amount))
{
  alert("enter numeric amount");
}
else {

  if(selectedFrom == "saving")
  {
    sessionStorage.setItem('fromI', sav);
    if(selectedTo == "checking")
    {
      sessionStorage.setItem('toI', check);
      if(amount<=sav)
      {
        check = parseFloat(check) + parseFloat(amount);
        sav = parseFloat(sav) - parseFloat(amount);
      }
      else {
        var total = parseFloat(sav) + parseFloat(creditAvail);
        if(total>=amount)
        {
          var add = parseFloat(sav) - parseFloat(amount);
          sav = parseFloat(0);
          creditAvail = parseFloat(creditAvail) + parseFloat(add);
            check = parseFloat(check) + parseFloat(amount);
            sessionStorage.setItem('fromA', sav);
            sessionStorage.setItem('toA', check);
            alert(check);
        }
        else {
          alert("invalid amount");
        }
      }
    }
    if(selectedTo == "others")
    {
      sessionStorage.setItem('toI', otherCheck);
      if(amount<=sav)
      {
        otherCheck = parseFloat(otherCheck) + parseFloat(amount)
        sav = parseFloat(sav) - parseFloat(amount);
      }
      else {
        var total = parseFloat(sav) + parseFloat(creditAvail);
        if(total>=amount)
        {
          var add = parseFloat(sav) - parseFloat(amount);
          sav = parseFloat(0);
          creditAvail = parseFloat(creditAvail) + parseFloat(add);
          otherCheck = parseFloat(otherCheck) + parseFloat(amount);
          sessionStorage.setItem('fromA', sav);
          sessionStorage.setItem('toA', otherCheck);
        }
        else {
          alert("invalid amount");
        }
      }
    }
  }
  if(selectedFrom == "checking")
  {
    sessionStorage.setItem('fromI', check);
    if(selectedTo == "saving")
    {
      sessionStorage.setItem('toI', sav);
      if(amount<=check)
      {
        sav = parseFloat(sav) + parseFloat(amount);
        check = parseFloat(check) - parseFloat(amount);

      }
      else {
        var total = parseFloat(check) + parseFloat(creditAvail);
        if(total>=amount)
        {
          var add = parseFloat(check) - parseFloat(amount);
          check = parseFloat(0);
          creditAvail = parseFloat(creditAvail) + parseFloat(add);
            sav = parseFloat(sav) + parseFloat(amount);
            sessionStorage.setItem('fromA', check);
            sessionStorage.setItem('toA', sav);
        }
        else {
          alert("invalid amount");
        }

      }
    }
    if(selectedTo == "others")
    {
      sessionStorage.setItem('toI', otherSav);
      if(amount<=check)
      {
        otherSav = parseFloat(otherSav) + parseFloat(amount);
        check = parseFloat(check) - parseFloat(amount);
      }
        else {
          var total = parseFloat(check) + parseFloat(creditAvail);
          if(total>=amount)
          {
            var add = parseFloat(check) - parseFloat(amount);
            check = parseFloat(0);
            creditAvail = parseFloat(creditAvail) + parseFloat(add);
            otherSav = parseFloat(otheSav) + parseFloat(amount);
            sessionStorage.setItem('fromA', check);
            sessionStorage.setItem('toA', otherSav);

          }
          else {
            alert("invalid amount");
          }

        }
        var d = new Date();
        if(sessionStorage.getItem('userDisp') == "user1")
        {
          localStorage.setItem('u2Chk',parseFloat(localStorage.getItem('u2Chk'))+parseFloat(amount));
          u1Date.push(d.toString());
          u1Out.push(parseFloat(amount));
          u1In.push(0);
          u1Bal.push(parseFloat(sav)+parseFloat(check))

          u2Date.push(d.toString());
          u2Out.push(0);
          u2In.push(parseFloat(amount));
          u2Bal.push(localStorage.getItem('u2Sav')+ localStorage.getItem('u2Chk'));


        }
        if(sessionStorage.getItem('userDisp') == "user2")
        {
          localStorage.setItem('u1Chk',parseFloat(localStorage.getItem('u1Chk'))+parseFloat(amount));
          u2Date.push(d.toString());
          u2Out.push(parseFloat(amount));
          u2In.push(0);
          u2Bal.push(parseFloat(sav)+parseFloat(check))

          u1Date.push(d.toString());
          u1Out.push(0);
          u1In.push(parseFloat(amount));
          u1Bal.push(localStorage.getItem('u1Sav')+ localStorage.getItem('u1Chk'));
        }

        localStorage.setItem('u1DateA',JSON.stringify(u1Date));
        localStorage.setItem('u1OutA',JSON.stringify(u1Out));
        localStorage.setItem('u1InA',JSON.stringify(u1In));
        localStorage.setItem('u1BalA',JSON.stringify(u1Bal));

        localStorage.setItem('u2DateA',JSON.stringify(u2Date));
        localStorage.setItem('u2OutA',JSON.stringify(u2Out));
        localStorage.setItem('u2InA',JSON.stringify(u2In));
        localStorage.setItem('u2BalA',JSON.stringify(u2Bal));
      }
    }
  }
  $("#credit").text("Total = " + creditTotal + "$ Available =" + creditAvail + "$");
  $("#finalB").text("Final Balanace->" + " saving = " + sav + "$ checking =" + check + "$");
  sessionStorage.setItem('from', selectedFrom);
  sessionStorage.setItem('to', selectedTo);

  if(sessionStorage.getItem('userDisp') == "user1")
  {
    localStorage.setItem('u1Sav',sav);
    localStorage.setItem('u1Chk',check);
    localStorage.setItem('u1Credit',creditAvail);
    if(selectedTo="others")
    {

    }
  }
  if(sessionStorage.getItem('userDisp') == "user2")
  {
    localStorage.setItem('u2Sav',sav);
    localStorage.setItem('u2Chk',check);
    localStorage.setItem('u2Credit',creditAvail);
    if(selectedTo="others")
    {

    }
  }

location.reload();
  window.open("index3.html");
}
