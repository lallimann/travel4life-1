var iBalS = $("#iBalS");
var aBalS = $("#aBalS");
var iBalT = $("#iBalT");
var aBalT = $("#aBalT");

var from = $("#source");
var to = $("#target");



from.text("SOURCE: " + sessionStorage.getItem('from'));
to.text("TARGET: " + sessionStorage.getItem('to'));

iBalS.val(sessionStorage.getItem('fromI') + " $");
aBalS.val(sessionStorage.getItem('fromA') + " $");
iBalT.val(sessionStorage.getItem('toI') + " $");
aBalT.val(sessionStorage.getItem('toA') + " $");
