

$("#name").text("ACCOUNT HOLDER NAME: " + sessionStorage.getItem('userDisp'));
